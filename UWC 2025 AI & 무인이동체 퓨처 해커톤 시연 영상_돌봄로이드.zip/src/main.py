# Updated file - coolsms imports removed
import time
import cv2
import numpy as np
from PIL import Image
import torch.nn as nn
import sys
import mysql.connector
from datetime import datetime
import pyttsx3
from sdk.api.message import Message
from sdk.exceptions import CoolsmsException


####MySQL 연결 설정
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='root1234',
    database='uwc_db'
)

cursor = conn.cursor()


# 1. 식사 감지 (분류)
import torch
from torchvision import transforms, models

def load_meal_model():
    model = models.resnet18(weights=None)
    model.fc = nn.Sequential(
        nn.Dropout(0.3),
        nn.Linear(model.fc.in_features, 1)
    )
    model.load_state_dict(torch.load("src/mealDetect/trained_model.pt", map_location="cpu", weights_only=True))
    model.eval()
    return model

meal_model = load_meal_model()
meal_transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor()
])

def detect_meal(image):
    input_tensor = meal_transform(image).unsqueeze(0)
    with torch.no_grad():
        output = meal_model(input_tensor)
        prob = torch.sigmoid(output).item()
        print(f"비식사 확률: {prob:.4f}")  # sigmoid 적용
    return prob < 0.2  # 식사 여부 기준

# 2. 복약 감지 (YOLOv8)
from pillDetect.pillDetector import PillDetector

pill_detector = PillDetector(weights_path="runs/detect/train6/weights/best.pt")

def detect_pill(image):
    frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    result = pill_detector.predict(frame)
    return len(result.boxes) > 0

# 3. 낙상 감지 (3D CNN)
from fallDetect.fallRecognizer import FallRecognizer

def load_fall_model():
    model = FallRecognizer()
    model.load_state_dict(torch.load("src/fallDetect_weights.pt", map_location="cpu", weights_only=True))
    model.eval()
    return model

fall_model = load_fall_model()
fall_transform = transforms.Compose([
    transforms.Resize((112, 112)),
    transforms.ToTensor()
])

def get_video_clip(num_frames=16):
    cap = cv2.VideoCapture(0)
    frames = []
    while len(frames) < num_frames:
        ret, frame = cap.read()
        if not ret:
            continue
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image = Image.fromarray(frame)
        tensor = fall_transform(image)  # (3, 112, 112)
        frames.append(tensor)
        time.sleep(0.05)  # 약 20 fps로 캡처
    cap.release()
    return torch.stack(frames)  # (16, 3, 112, 112)

def detect_fall():
    clip = get_video_clip()         # (16, 3, 112, 112)

    # permute 생략! FallRecognizer 내부에서 처리함
    clip = clip.unsqueeze(0)        # (1, 16, 3, 112, 112)

    with torch.no_grad():
        output = fall_model(clip)
        pred = output.argmax(dim=1).item()

    return pred == 1

# 4. 휴지 감지 (YOLOv8)
from ultralytics import YOLO

toiletpaper_model = YOLO("runs/detect/train6/weights/best.pt")

def count_toiletpaper(image):
    results = toiletpaper_model(image)
    return len(results[0].boxes)

# 5. 쌀 감지 (분류/분할)
from riceDetect.model import UNet  # 모델 정의 파일에서 가져오기

# U-Net 모델 로드 (Segmentation 용)
rice_model = UNet(num_classes=1)
rice_model.load_state_dict(torch.load("models/riceSeg.pt", map_location="cpu", weights_only=True))
rice_model.eval()

# 이미지 전처리
rice_transform = transforms.Compose([
    transforms.Resize((512, 512)),  # 학습 시 사용한 크기로
    transforms.ToTensor()
])

def measure_rice(image):
    # 1. 이미지 전처리
    input_tensor = rice_transform(image).unsqueeze(0)  # (1, 3, 512, 512)

    # 2. 마스크 예측
    with torch.no_grad():
        output = rice_model(input_tensor)  # (1, 1, 512, 512)
        mask = torch.sigmoid(output)       # 확률값
        binary_mask = (mask > 0.5).float() # 이진화 → 1: 쌀, 0: 배경

    # 3. 쌀 비율 계산 (0.0 ~ 1.0)
    rice_ratio = binary_mask.mean().item()
    print(f"쌀 비율: {rice_ratio:.2f}")

    # 4. 비율 → 5단계 분류 (숫자로 반환)
    if rice_ratio < 0.2:
        return 10.0  # 10%를 10.0으로 반환
    elif rice_ratio < 0.4:
        return 30.0  # 30%를 30.0으로 반환
    elif rice_ratio < 0.6:
        return 50.0  # 50%를 50.0으로 반환
    elif rice_ratio < 0.8:
        return 70.0  # 70%를 70.0으로 반환
    else:
        return 90.0  # 90%를 90.0으로 반환

# 6. 복약 알림(음성)
def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

# 7. DB 저장 함수 import
from db import save_toiletpaper_count, save_rice_amount

# 8. 실시간 영상 스트림 처리 (get_current_image 함수 제거됨)

# 9. 메인 서비스 루프
def main():
    # 시간 추적 변수들
    last_meal_time = None
    pill_checked = False
    last_db_update = time.time()  # DB 업데이트 시간 추적
    last_fall_check = time.time()  # 낙상 감지 시간 추적
    last_meal_check = time.time() # 식사 감지 시간 추적
    last_toiletpaper_check = time.time() # 휴지 감지 시간 추적
    last_rice_check = time.time() # 쌀 감지 시간 추적

    # 카메라 연결을 한 번만 생성 (실시간 스트림)
    # 카메라 인덱스: 0=내장카메라, 1=USB웹캠, 2=외부카메라
    camera_index = 0  # 필요시 1, 2로 변경
    
    # 여러 카메라 인덱스 시도
    cap = None
    for idx in [0, 1, 2]:  # 0, 1, 2 순서로 시도
        print(f"카메라 {idx} 연결 시도 중...")
        cap = cv2.VideoCapture(idx)
        if cap.isOpened():
            # 테스트 프레임 읽기
            ret, test_frame = cap.read()
            if ret and test_frame is not None and test_frame.size > 0:
                print(f"카메라 {idx} 연결 성공!")
                camera_index = idx
                break
            else:
                cap.release()
                print(f"카메라 {idx} 테스트 실패")
        else:
            print(f"카메라 {idx} 열기 실패")
    
    if cap is None or not cap.isOpened():
        print("사용 가능한 카메라를 찾을 수 없습니다.")
        return

    # 카메라 설정 최적화 (안정성 향상)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)   # 너비 설정
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)  # 높이 설정
    cap.set(cv2.CAP_PROP_FPS, 30)           # FPS 설정
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)     # 버퍼 크기 최소화
    cap.set(cv2.CAP_PROP_AUTOFOCUS, 1)      # 자동 초점
    cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 1)  # 자동 노출
    
    print("실시간 영상 감지 시작! (Q 키로 종료)")
    
    while True:
        current_time = time.time()
        
        # 실시간 프레임 읽기
        ret, frame = cap.read()
        if not ret:
            print(f"카메라에서 프레임을 읽을 수 없습니다. 재연결 시도 중...")
            print(f"카메라 상태: 열림={cap.isOpened()}")
            
            # 카메라 재연결 시도 (무한 시도)
            cap.release()
            time.sleep(2)  # 2초 대기
            cap = cv2.VideoCapture(camera_index) # 원래 인덱스로 다시 시도
            if cap.isOpened():
                # 재연결 후 설정 다시 적용
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                cap.set(cv2.CAP_PROP_FPS, 30)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                print("카메라 재연결 성공!")
            else:
                print("카메라 재연결 실패! 계속 시도합니다...")
            continue
        
        # 프레임이 유효할 때만 영상 표시 및 AI 감지
        if ret and frame is not None and frame.size > 0:
            # 실시간 영상 표시
            cv2.imshow("Camera", frame)
            key = cv2.waitKey(1)
            if key == ord('q') or key == ord('Q'):  # q 또는 Q 키
                print("Q 키가 눌려 프로그램을 종료합니다.")
                break
                
            # PIL 이미지로 변환 (AI 모델용)
            image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

            # 사진 찍기 방식: 일정 간격으로만 AI 감지 (렉 방지)
            # 실시간 스트림 방식: 매 프레임마다 AI 감지 (더 정확하지만 렉 발생)
            detection_mode = "realtime"  # "photo" 또는 "realtime"
            
            if detection_mode == "photo":
                # 사진 찍기 방식: 10초마다 사진 찍어서 감지 (렉 방지)
                if current_time - last_db_update > 10:
                    print("사진을 찍어서 AI 감지를 수행합니다...")
                    
                    # 1. 식사 감지 (가장 빠른 모델)
                    meal = detect_meal(image)
                    if meal:
                        print("식사 감지됨!")
                        last_meal_time = time.time()
                        pill_checked = False

                    # 2. 식사 후 30분 뒤 복약 감지(음성)
                    if last_meal_time and not pill_checked:
                        if time.time() - last_meal_time > 30:  # 테스트용 30초, 실제 동작 1800초(30분)
                            speak("복약 시간이 되었습니다. 약을 복용하세요.")
                            pill_checked = True

                    # 3. 낙상 감지 (비활성화 - 렉 방지)
                    if current_time - last_fall_check > 5:
                        fall = detect_fall()  # 매우 느린 함수
                        if fall:
                            print("낙상 감지됨! SMS 알림을 보냅니다.")
                            # SMS 코드...
                        last_fall_check = current_time
                    # print("낙상 감지는 성능상 비활성화됨")

                    # 4. 휴지 감지 (중간 속도)
                    toiletpaper = count_toiletpaper(image)
                    print(f"휴지 개수: {toiletpaper}")

                    # 5. 쌀 감지 (중간 속도)
                    rice = measure_rice(image)
                    print(f"쌀 잔량: {rice:.0f}%")

                    # 6. DB 저장
                    save_toiletpaper_count(toiletpaper)
                    save_rice_amount(rice)
                    last_db_update = current_time
                    print("DB 업데이트 완료")
                    
            else:
                # 실시간 스트림 방식: 매 프레임마다 감지 (기존 방식)
                # 1. 식사 감지 (2초마다 - 렉 방지)
                if current_time - last_meal_check > 2:
                    meal = detect_meal(image)
                    if meal:
                        print("식사 감지됨!")
                        last_meal_time = time.time()
                        pill_checked = False
                    last_meal_check = current_time

                # 2. 식사 후 30분 뒤 복약 감지(음성)
                if last_meal_time and not pill_checked:
                    if time.time() - last_meal_time > 30:  # 테스트용 30초 (실제 서비스는 1800초=30분)
                        speak("복약 시간이 되었습니다. 약을 복용하세요.")
                        pill_checked = True

                # 3. 낙상 감지 (5초마다 - 렉 방지)
                if current_time - last_fall_check > 5:
                    fall = detect_fall()
                    if fall:
                        print("낙상 감지됨! SMS 알림을 보냅니다.")
                
                        #### pip install coolsms_python_sdk
                        # ### @brief This sample code demonstrate how to send sms through CoolSMS Rest API PHP
                        # set api key, api secret
                        api_key = 'NCSTOOV3ALOKFAVX'
                        api_secret = '6VVFDM4UPJ1XTCEUOVHA0KWORNHXKF5K'
                
                        ## 4 params(to, from, type, text) are mandatory. must be filled
                        params = dict()
                        params['type'] = 'sms' # Message type ( sms, lms, mms, ata )
                        params['to'] = '01045201776' # Recipients Number '01000000000,01000000001'
                        params['from'] = '01045201776' # Sender number
                        params['text'] = '낙상이 감지되었습니다' # Message
                
                        cool = Message(api_key, api_secret)
                        try:
                            response = cool.send(params)
                            print("Success Count : %s" % response['success_count'])
                            print("Error Count : %s" % response['error_count'])
                            print("Group ID : %s" % response['group_id'])
                
                            if "error_list" in response:
                                print("Error List : %s" % response['error_list'])
                
                        except CoolsmsException as e:
                            print("Error Code : %s" % e.code)
                            print("Error Message : %s" % e.msg)
                
                        # sys.exit() 대신 print 사용 (카메라 종료 방지)
                        print("SMS 전송 완료. 프로그램을 계속 실행합니다.")
                    last_fall_check = current_time

                # 4. 휴지 감지 (3초마다 - 렉 방지)
                if current_time - last_toiletpaper_check > 3:
                    toiletpaper = count_toiletpaper(image)
                    print(f"휴지 개수: {toiletpaper}")
                    last_toiletpaper_check = current_time

                # 5. 쌀 감지 (3초마다 - 렉 방지)
                if current_time - last_rice_check > 3:
                    rice = measure_rice(image)
                    print(f"쌀 잔량: {rice:.0f}%")
                    last_rice_check = current_time

                # 6. DB 저장 (5초마다 - 렉 방지)
                if current_time - last_db_update > 5:
                    save_toiletpaper_count(toiletpaper)
                    save_rice_amount(rice)
                    last_db_update = current_time
                    print("DB 업데이트 완료")
        else:
            print("유효하지 않은 프레임입니다. 건너뜁니다.")

        time.sleep(1)  # 1초마다 반복 (렉 방지)
    
    # 카메라 연결 해제
    cap.release()

if __name__ == "__main__":
    try:
        main()
    finally:
        cv2.destroyAllWindows()  # 모든 OpenCV 창 닫기