import torch                 # PyTorch 디바이스 확인용

def get_device():
    """CUDA(GPU)가 있으면 'cuda', 없으면 'cpu' 디바이스 객체 반환"""
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")
