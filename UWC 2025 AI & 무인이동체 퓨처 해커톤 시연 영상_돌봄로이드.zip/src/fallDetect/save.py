import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models

# 예시로 CNN 모델을 정의 (ResNet-18 사용)
class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN, self).__init__()
        self.resnet = models.resnet18(pretrained=True)
        self.fc = nn.Linear(self.resnet.fc.in_features, 2)  # 2개 클래스를 분류한다고 가정

    def forward(self, x):
        x = self.resnet(x)  # ResNet-18 모델을 통한 피처 추출
        x = self.fc(x)  # 분류기
        return x

# 모델 초기화
model = SimpleCNN()

# 학습이 끝난 후 모델을 저장 (모델 구조와 가중치 모두 저장)
model_save_path = 'c:/uwc/src/mealDetect/cnn_trained_model.pt'
torch.save(model, model_save_path)

print(f'Model saved at {model_save_path}')
