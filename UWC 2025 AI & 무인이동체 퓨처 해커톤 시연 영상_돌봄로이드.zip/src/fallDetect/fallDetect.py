import torch
from fallDetect.fallRecognizer import FallRecognizer
from torchvision import transforms

# 모델 로드 (최초 1회만)
_model = None
def load_fall_model():
    global _model
    if _model is None:
        _model = FallRecognizer()
        _model.load_state_dict(torch.load("fall_model.pt", map_location="cpu"))  # 실제 경로로 수정
        _model.eval()
    return _model

_transform = transforms.Compose([
    transforms.Resize((112, 112)),
    transforms.ToTensor()
])

def detect_fall(image):
    """
    이미지를 입력받아 낙상 여부를 실제 모델로 감지합니다.
    """
    model = load_fall_model()
    input_tensor = _transform(image).unsqueeze(0).unsqueeze(2)  # (B,1,C,H,W)
    with torch.no_grad():
        output = model(input_tensor)
        pred = output.argmax(dim=1).item()
    return pred == 1  # 1번 클래스가 낙상