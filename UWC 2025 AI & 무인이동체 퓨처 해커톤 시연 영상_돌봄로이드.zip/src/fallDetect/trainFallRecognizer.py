import torch                                    # 텐서 연산
import torch.nn.functional as F                 # CrossEntropyLoss
from torch.utils.data import DataLoader, random_split

from .fallDataset    import FallDataset         # 같은 폴더 import
from .fallRecognizer import FallRecognizer      # 〃
from ..utils         import get_device          # 상위 폴더 import


def train():
    device = get_device()                       # GPU or CPU

    ds = FallDataset("annotations.csv", clipLen=16)  # 전체 데이터
    n_train = int(len(ds) * 0.8)                # 80% 학습
    n_val   = len(ds) - n_train                 # 20% 검증
    train_ds, val_ds = random_split(ds, [n_train, n_val])

    train_ld = DataLoader(train_ds, batch_size=4, shuffle=True)
    val_ld   = DataLoader(val_ds,   batch_size=4)

    model = FallRecognizer().to(device)         # 모델 GPU 업로드
    optim = torch.optim.Adam(model.parameters(), lr=1e-4)

    for epoch in range(5):
        # ---------- 학습 ----------
        model.train()
        for clips, labels in train_ld:
            clips, labels = clips.to(device), labels.to(device)
            loss = F.cross_entropy(model(clips), labels)
            optim.zero_grad()
            loss.backward()
            optim.step()

        # ---------- 검증 ----------
        model.eval()
        correct = 0                              # ← 초기화
        total   = 0                              # ← 초기화
        with torch.no_grad():
            for clips, labels in val_ld:
                clips, labels = clips.to(device), labels.to(device)
                preds = model(clips).argmax(1)
                correct += (preds == labels).sum().item()
                total   += labels.size(0)

        val_acc = correct / total * 100
        print(f"Epoch {epoch+1}: valAcc = {val_acc:.1f}%")

if __name__ == "__main__":
    train()
    

