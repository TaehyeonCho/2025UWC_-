import torch.nn as nn
from torchvision.models.video import r3d_18

class FallRecognizer(nn.Module):
    """(B,T,C,H,W) 또는 (B,1,C,H,W) 입력 → 2-클래스 로짓 출력"""

    def __init__(self):
        super().__init__()
        self.backbone = r3d_18(weights="KINETICS400_V1")  # 최신 enum 사용
        self.backbone.fc = nn.Linear(512, 2)               # fall / noFall

    def forward(self, clip):
        if clip.dim() == 4:              # 이미지(T=1) → (B,1,C,H,W)
            clip = clip.unsqueeze(1)
        # (B,T,C,H,W)  →  (B,C,T,H,W) 로 차원 순서 변경
        clip = clip.permute(0, 2, 1, 3, 4).contiguous()
        return self.backbone(clip)
