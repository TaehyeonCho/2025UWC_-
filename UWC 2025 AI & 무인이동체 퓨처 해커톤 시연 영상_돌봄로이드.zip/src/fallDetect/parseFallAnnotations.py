import os, csv                         # 경로·CSV
from glob import glob                  # 파일 검색

annoDir  = "data/fall/annotations"     # 1) GT .txt 폴더
videoDir = "data/fall/videos"          # 2) 비디오 .avi 폴더
csvOut   = "annotations.csv"           # 3) 출력 CSV 경로

# ---- 디버그 출력 -------------------------------------------------
txtFiles  = glob(os.path.join(annoDir, "*.txt"))
aviFiles  = glob(os.path.join(videoDir, "*.avi"))
print(f"Found {len(txtFiles)} txt files  in {annoDir}")
print(f"Found {len(aviFiles)} avi files in {videoDir}")
# -----------------------------------------------------------------

rows = []                               # CSV 행 담을 리스트
for txtPath in txtFiles:                # GT 파일 순회
    vidName = os.path.basename(txtPath).replace(".txt", ".avi")
    vidPath = os.path.join(videoDir, vidName)
    if not os.path.exists(vidPath):     # 비디오가 없으면 경고
        print("WARN: avi not found for", vidName)
        continue

    with open(txtPath, encoding="utf-8") as f:
        start = int(f.readline().strip())
        end   = int(f.readline().strip())
    label = 1 if end > start else 0     # fall=1 / noFall=0
    rel   = os.path.relpath(vidPath, ".")
    rows.append([rel, label, "video", "fall"])

# ---- CSV 저장 ----------------------------------------------------
with open(csvOut, "w", newline="", encoding="utf-8") as f:
    csv.writer(f).writerows([["path","label","type","task"]] + rows)

print(f"annotations.csv saved ({len(rows)} samples)")