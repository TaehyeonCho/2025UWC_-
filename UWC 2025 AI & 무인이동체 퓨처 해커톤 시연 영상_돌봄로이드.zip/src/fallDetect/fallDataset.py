import csv, cv2, torch
from torch.utils.data import Dataset

TARGET_SIZE = (112, 112)           # (W, H) 모든 프레임을 고정 리사이즈

class FallDataset(Dataset):
    """이미지 + 비디오를 모두 처리하는 낙상 데이터셋"""

    def __init__(self, csvPath: str, clipLen: int = 16, transforms=None):
        self.items = [row for row in csv.DictReader(open(csvPath, encoding="utf-8"))]
        self.clipLen   = clipLen
        self.transforms = transforms

    def __len__(self):
        return len(self.items)

    def _to_tensor(self, img):
        """Numpy H × W × C(BGR) → Tensor C × H × W(RGB) + 0 – 1 정규화"""
        img = cv2.resize(img, TARGET_SIZE)      # ① 해상도 고정
        img = img[:, :, ::-1].copy()            # ② BGR→RGB + .copy() (stride 양수)
        if self.transforms:
            img = self.transforms(img)
        return torch.from_numpy(img).permute(2, 0, 1).float() / 255.0

    def __getitem__(self, idx):
        row   = self.items[idx]
        path  = row["path"];  label = int(row["label"]); typ = row["type"]

        # ─ 이미지 샘플 ─────────────────────────────────────────────
        if typ == "image":
            img  = cv2.imread(path)
            clip = self._to_tensor(img).unsqueeze(0)   # (1, C, H, W)

        # ─ 비디오 샘플 ─────────────────────────────────────────────
        else:
            cap   = cv2.VideoCapture(path)
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            step  = max(1, total // self.clipLen)
            frames = []
            for i in range(self.clipLen):
                cap.set(cv2.CAP_PROP_POS_FRAMES, i * step)
                ret, frm = cap.read()
                if not ret: break
                frames.append(self._to_tensor(frm))
            cap.release()
            clip = torch.stack(frames)                # (T, C, H, W)

        # clip shape: (T, C, H, W) 보장
        return clip, label

