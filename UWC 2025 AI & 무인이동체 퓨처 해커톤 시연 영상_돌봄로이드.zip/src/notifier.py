def send_sms(message, to):
    """
    지정한 번호(to)로 메시지(message)를 전송합니다.
    실제로는 SMS API 연동 코드가 필요합니다.
    """
    # TODO: SMS API 연동 코드 작성
    print(f"[SMS to {to}] {message}")