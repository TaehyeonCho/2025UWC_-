import cv2
import torch
from ultralytics import YOLO
from typing import Optional

class PillDetector:
    def __init__(self,
                 weights_path: str = 'models/pill.pt',
                 device: Optional[str] = None):
        """
        모델 로드 및 초기화
        :param weights_path: 학습된 모델(.pt) 파일 경로
        :param device: 'cuda' 또는 'cpu'; None이면 자동 탐지
        """
        # device 자동 탐지: CUDA 사용 가능 시 'cuda', 아니면 'cpu'
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')

        # YOLOv8 모델 로드 후 디바이스로 이동
        self.model = YOLO(weights_path)
        self.model.to(self.device)

        # 탐지 신뢰도·NMS 임계치
        self.conf_threshold = 0.5
        self.iou_threshold  = 0.45

    def predict(self, frame):
        """
        한 프레임에 대해 알약 탐지 수행
        :param frame: OpenCV BGR 이미지 (np.ndarray)
        :return: 모델 결과 객체
        """
        # BGR → RGB 변환
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        # 추론
        results = self.model(
            img,
            imgsz=640,
            conf=self.conf_threshold,
            iou=self.iou_threshold,
            device=self.device
        )
        return results[0]

    def draw(self, frame, result):
        """
        탐지 결과를 프레임에 오버레이
        :param frame: 원본 BGR 이미지
        :param result: predict() 반환 객체
        :return: annotation이 그려진 BGR 이미지
        """
        boxes   = result.boxes.xyxy.cpu().numpy()      # [N,4]
        scores  = result.boxes.conf.cpu().numpy()      # [N]
        classes = result.boxes.cls.cpu().numpy().astype(int)  # [N]

        for (x1, y1, x2, y2), score in zip(boxes, scores):
            x1, y1, x2, y2 = map(int, (x1, y1, x2, y2))
            label = f'pill {score:.2f}'

            # 1) 바운딩 박스
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            # 2) 레이블 배경
            (w, h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
            cv2.rectangle(frame, (x1, y1 - 20), (x1 + w, y1), (0, 255, 0), -1)
            # 3) 텍스트 그리기
            cv2.putText(
                frame,
                label,
                (x1, y1 - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                1,
                cv2.LINE_AA
            )

        return frame

    def set_thresholds(self, conf: float, iou: float):
        """
        신뢰도·IOU 임계치 조정
        """
        self.conf_threshold = conf
        self.iou_threshold  = iou
            