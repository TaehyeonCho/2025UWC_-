# C:\uwc\src\mealDetect\detectTrain.py

import os
import torch
from ultralytics import YOLO

def main():
    # KMP 충돌 방지
    os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

    # 사전 학습된 YOLOv8n 모델 로드
    model = YOLO("yolov8n.pt")

    # 학습 실행
    model.train(
        data="C:/uwc/data/med/c3pi/c3pi.yaml",  # 데이터셋 설정 파일 경로
        epochs=50,                              # 학습 에폭 수
        batch=16,                               # 배치 크기
        imgsz=640,                              # 이미지 사이즈
        device=0,                               # GPU 0번 사용
        save_period=1,                          # 매 에폭마다 체크포인트 저장
        project="runs/med_detect",              # 결과 저장 폴더
        name="c3piTrain"                        # 실행 세션 이름
        # ※ auto_label 인자는 제거했습니다.
    )

    print("✅ Medication detection training complete! Check runs/med_detect/c3piTrain")

if __name__ == "__main__":
    main()
