import cv2
from pillDetect.pillDetector import PillDetector

# 모델 로드 (최초 1회만)
_detector = None
def get_detector():
    global _detector
    if _detector is None:
        _detector = PillDetector(weights_path="runs/detect/train6/weights/best.pt")
    return _detector

def detect_pill(image):
    """
    이미지를 입력받아 복약 여부를 실제 모델로 감지합니다.
    """
    detector = get_detector()
    # PIL → OpenCV 변환
    frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    result = detector.predict(frame)
    # 예시: pill 클래스가 1개 이상 감지되면 복약 감지
    return len(result.boxes) > 0