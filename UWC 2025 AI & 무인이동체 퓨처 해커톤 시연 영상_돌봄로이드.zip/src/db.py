import mysql.connector

# 전역 DB 연결 (성능 최적화)
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='root1234',
    database='uwc_db'
)

cursor = conn.cursor()

# db.py

import mysql.connector

def save_toiletpaper_count(count: int):
    item_name = '휴지'

    try:
        # 전역 커넥션 사용
        global cursor

        # 3) 기존 레코드 조회
        cursor.execute(
            "SELECT count FROM item_count WHERE item_name = %s",
            (item_name,)
        )
        row = cursor.fetchone()

        if row:
            # 4-1) 있으면 개수 누적
            cursor.execute(
                "UPDATE item_count SET count = count + %s WHERE item_name = %s",
                (count, item_name)
            )
        else:
            # 4-2) 없으면 새로 삽입
            cursor.execute(
                "INSERT INTO item_count (item_name, count) VALUES (%s, %s)",
                (item_name, count)
            )

        # 5) 커밋
        conn.commit()
        print(f"[DB] {item_name} 처리 완료")
        print(f"DB 저장: {item_name} 개수 = {count}")

    finally:
        # 전역 연결은 유지 (성능 최적화)
        pass


####쌀 잔량 덮어쓰기 함수

def save_rice_amount(amount: float):
    item_name = '쌀'
    try:
        # 전역 커넥션 사용
        global cursor

        # 3) 기존 레코드 조회
        cursor.execute(
            "SELECT count FROM item_count WHERE item_name = %s",
            (item_name,)
        )
        row = cursor.fetchone()

        if row:
            # 4-1) 있으면 UPDATE
            cursor.execute(
                "UPDATE item_count SET count = %s WHERE item_name = %s",
                (amount, item_name)
            )
        else:
            # 4-2) 없으면 INSERT
            cursor.execute(
                "INSERT INTO item_count (item_name, count) VALUES (%s, %s)",
                (item_name, amount)
            )

        # 5) 커밋
        conn.commit()
        print(f"[DB] {item_name} 잔량 {amount:.0f}% 저장 완료")

    finally:
        # 전역 연결은 유지 (성능 최적화)
        pass

    
    