import os                             # 파일 경로 조작용
import shutil                         # 파일 복사용
from glob import glob                 # 와일드카드 파일 검색용

# 1) YOLO class_id → 분류용 폴더명 매핑
class_map = {
    "0": "fall",     # YOLO 라벨 0 → export/fall
    "1": "noFall"    # YOLO 라벨 1 → export/noFall
}

# 2) 원본 이미지 & 라벨이 들어 있는 디렉토리 경로
img_dir   = "C:/uwc/data/fall/images/train/images"    # C:/uwc/data/fall/images/train/images/*.jpg
label_dir = "C:/uwc/data/fall/images/train/labels"    # data/fall/labelsTrain/*.txt

# 3) 출력(export) 폴더를 미리 생성
out_root = "export"                   # export/ 아래에 클래스별 폴더 생성
for cls in class_map.values():
    os.makedirs(os.path.join(out_root, cls), exist_ok=True)

# 4) 각 .txt 파일을 순회하며 이미지 복사
for txt_path in glob(os.path.join(label_dir, "*.txt")):
    # 4-1) txt 파일명으로부터 대응하는 이미지 파일명 생성
    fname = os.path.basename(txt_path).replace(".txt", ".jpg")
    img_path = os.path.join(img_dir, fname)

    # 4-2) .jpg 없으면 .png로도 시도
    if not os.path.exists(img_path):
        img_path = img_path.replace(".jpg", ".png")
        if not os.path.exists(img_path):
            continue  # 이미지가 없으면 건너뜀

    # 4-3) 라벨 파일에서 첫 줄(class_id) 읽기
    with open(txt_path, "r") as f:
        parts = f.readline().strip().split()
        if not parts:
            continue
        class_id = parts[0]          # 리스트 첫 번째 요소가 class_id

    # 4-4) 매핑 테이블에서 최종 클래스 이름 가져오기
    cls_name = class_map.get(class_id)
    if cls_name is None:
        continue                     # 매핑에 없는 class_id면 스킵

    # 4-5) 이미지 → export/<cls_name>/ 디렉토리로 복사
    dst = os.path.join(out_root, cls_name, fname)
    shutil.copy(img_path, dst)

# 5) 완료 메시지 출력
print("Classification dataset ready in", out_root)