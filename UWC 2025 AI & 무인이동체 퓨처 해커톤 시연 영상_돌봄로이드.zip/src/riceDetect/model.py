# src/riceDetect/model.py

import torch
import torch.nn as nn
import torch.nn.functional as F

class DoubleConv(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_c, out_c, 3, padding=1),
            nn.BatchNorm2d(out_c),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_c, out_c, 3, padding=1),
            nn.BatchNorm2d(out_c),
            nn.ReLU(inplace=True),
        )
    def forward(self, x):
        return self.net(x)

class UNet(nn.Module):
    def __init__(self, num_classes=1):
        super().__init__()
        self.dconv_down1 = DoubleConv(3, 64)
        self.dconv_down2 = DoubleConv(64, 128)
        self.dconv_down3 = DoubleConv(128, 256)
        self.dconv_down4 = DoubleConv(256, 512)

        self.maxpool = nn.MaxPool2d(2)
        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)

        self.dconv_up3 = DoubleConv(256+512, 256)
        self.dconv_up2 = DoubleConv(128+256, 128)
        self.dconv_up1 = DoubleConv(128+64, 64)

        self.conv_last = nn.Conv2d(64, num_classes, 1)

    def forward(self, x):
        conv1 = self.dconv_down1(x)
        x     = self.maxpool(conv1)

        conv2 = self.dconv_down2(x)
        x     = self.maxpool(conv2)

        conv3 = self.dconv_down3(x)
        x     = self.maxpool(conv3)

        x     = self.dconv_down4(x)

        x     = self.upsample(x)
        x     = torch.cat([x, conv3], dim=1)

        x     = self.dconv_up3(x)
        x     = self.upsample(x)
        x     = torch.cat([x, conv2], dim=1)

        x     = self.dconv_up2(x)
        x     = self.upsample(x)
        x     = torch.cat([x, conv1], dim=1)

        x     = self.dconv_up1(x)

        out = self.conv_last(x)
        return out
