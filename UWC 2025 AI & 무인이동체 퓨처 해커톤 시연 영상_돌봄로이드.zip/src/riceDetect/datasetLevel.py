import os
from PIL import Image
import torch
from torch.utils.data import Dataset

class RiceLevelDataset(Dataset) :
    """
    real_rice/
      level_0/    ← 빈 통 사진
      level_50/   ← 절반 찬 통 사진
      level_100/  ← 가득 찬 통 사진
    """
    
    def __init__(self, root_dir, transform=None) :
        """
        :param root_dir: 'data/real_rice'
        :param transform: torchvision.transforms 적용 (Resize, ToTensor, Normalize 등)
        """
        
        self.transform = transform
        self.samples = []
        
        #각 레벨 폴더를 순회하며 이미지 경로와 레이블을 저장
        for folder, label in [{'level_0', 0.0}, ('level_50', 0.5), ('level_100', 1.0)] : 
            folder_path = os.path.join(root_dir, folder)
            #디렉토리가 존재하면 그 안을 처리
            if os.path.isdir(folder_path) :
                for frame in os.listdir(folder_path) :
                    #이미지 파일만 처리
                    if frame .lower().endswith(('.png','.jpg','jpeg')) :
                        path = os.path.join(folder_path, frame)
                        #샘플 목록에 추가
                        self.samples.append({
                            'path' : path,
                            'label' : label
                        })
                        
                    else : 
                        #이미지 마일이 아니면 넘어감
                        continue
            else :
                #폴더가 없으면 건너뜀
                continue
            
    def __len__(self) : 
        #샘플 갯수 반환
        return len(self.samples)
    
    def __getitem__(self, idx) : 
        #샘플 정보 조회
        sample = self.samples[idx]
        path = sample['path'] # 이미지 파일 경로
        label = sample['label'] # 레이블 (0.0, 0.5, 1.0)
        
        #이미지 로드 및 RBG 반환
        
        img = Image.open(path).convert('RGB')
        # transform이 있으면 적용
        if self.transform :
            img = self.transform(img)
            
        else :
            #transform이 없으면 원본 PIL 이미지 반환
            pass
        
        #레이블을 텐서로 반환
        label_tensor = torch.tensor(label, dtype=torch.float32)
        return img, label_tensor