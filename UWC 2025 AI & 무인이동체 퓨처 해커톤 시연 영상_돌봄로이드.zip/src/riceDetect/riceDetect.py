from PIL import Image

def measure_rice(image):
    """
    이미지를 입력받아 쌀 잔량(kg 등)을 반환합니다.
    실제로는 모델을 불러와서 추론해야 합니다.
    """
    # TODO: 모델 로드 및 추론 코드 작성
    rice_amount = 1.5  # 임시로 1.5kg 반환
    return rice_amount