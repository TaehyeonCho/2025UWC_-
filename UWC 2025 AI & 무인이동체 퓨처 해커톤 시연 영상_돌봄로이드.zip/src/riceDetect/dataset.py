# src/riceDetect/dataset.py

import os
import cv2
import torch
from torch.utils.data import Dataset

class RiceSegDataset(Dataset):
    def __init__(self, img_dir, mask_dir, augment=False):
        self.img_dir  = img_dir
        self.mask_dir = mask_dir
        self.augment  = augment
        # '_Depth.png' 로 끝나는 이미지 목록만
        self.images  = sorted([f for f in os.listdir(img_dir) if f.endswith('_Depth.png')])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_name  = self.images[idx]                            # Content_Frame_0_Depth.png
        img_path  = os.path.join(self.img_dir, img_name)
        # mask 파일명: Depth → Mask
        mask_name = img_name.replace('_Depth.png', '_Mask.png') # Content_Frame_0_Mask.png
        mask_path = os.path.join(self.mask_dir, mask_name)

        # 디버그: 경로 출력
        if idx < 5:
            print(f"[DEBUG] idx={idx}, img_path={img_path}, mask_path={mask_path}")

        # 파일 존재 확인
        if not os.path.isfile(img_path):
            raise FileNotFoundError(f"Image not found: {img_path}")
        if not os.path.isfile(mask_path):
            raise FileNotFoundError(f"Mask not found: {mask_path}")

        # 읽기
        img  = cv2.imread(img_path)
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        if mask is None:
            raise ValueError(f"Failed to load mask (None): {mask_path}")

        # 리사이즈
        img  = cv2.resize(img,  (512,512))
        mask = cv2.resize(mask, (512,512), interpolation=cv2.INTER_NEAREST)

        # 증강
        if self.augment and torch.rand(1) < 0.5:
            img  = cv2.flip(img,  1)
            mask = cv2.flip(mask, 1)

        # 전처리
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) / 255.0
        img = torch.from_numpy(img).permute(2,0,1).float()
        mask = (mask > 0).astype('float32')
        mask = torch.from_numpy(mask).unsqueeze(0)

        return img, mask
