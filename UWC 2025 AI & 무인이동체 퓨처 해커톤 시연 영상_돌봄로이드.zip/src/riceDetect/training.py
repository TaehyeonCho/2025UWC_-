import os
import torch
import torch.nn as nn # 신경망 모듈 (손실함수 등)
import torch.optim as optim # 최적화 알고리즘
from torch.utils.data import DataLoader

from dataset import RiceSegDataset
from model   import UNet


def trainSeg(
    imgDir: str     = '../../data/transSolid/images',  # 입력 이미지 폴더 경로
    maskDir: str    = '../../data/transSolid/masks',   # 대응 마스크 폴더 경로
    epochs: int     = 50,                              # 학습 전체 반복(epoch) 횟수
    batchSize: int  = 8,                               # 한 번에 처리할 샘플 수
    lr: float       = 1e-4                             # 학습률(learning rate)
):
    
    # 1) 디바이스 설정 GPU가 있으면 사용, 없으면 CPU 사용
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f'학습에 {device}를 사용합니다')

    # 2) 데이터셋 및 DataLoader 준비
    trainDs    = RiceSegDataset(imgDir, maskDir, augment=True)   # 학습용: 증강(True)
    trainLoader = DataLoader(
        trainDs,
        batch_size=batchSize,
        shuffle=True,      # 매 epoch마다 데이터 순서 섞기
        num_workers=4      # 데이터 로딩 워커 수 (환경에 맞게 조정)
    )

    # 3) 모델/손실함수/옵티마이저 초기화
    model = UNet(num_classes=1).to(device) #U-Net 모델 생성 후 디바이스로 이동
    criterion = nn.BCEWithLogitsLoss() # 이진 분할용 손실 함수
    optimizer = optim.Adam(model.parameters(), lr = lr) # Adam 옵티마이저 설정
    
    # 4) 학습 루프
    for epoch in range(1, epochs + 1) :
        model.train() # 모델을 학습 모드로 전환
        totalLoss = 0.0 # epoch당 누적 손실 초기화
        
        # 4-1) 배치 단위 반복
        for imgs, masks in trainLoader :
            # a 데이터 디바이스로 이동
            imgs, masks = imgs.to(device), masks.to(device)

            # b 순전파(forward) 예측 마스크 계산
            preds = model(imgs) 
            
            # c 손실 계산
            loss = criterion(preds, masks)
            
            # d 역전파 (backward) 및 가중치 갱신
            optimizer.zero_grad() # 이전 기울기 초기화
            loss.backward() # 기술기 계산
            optimizer.step() # 파라미터 업데이트
            
            totalLoss += loss.item() # 배치 손실 누적
            
        # 4-2) epoch 종료 시 평균 손실 출력
        avgLoss = totalLoss / len(trainLoader)
        print(f"Epoch {epoch}/{epochs} Loss : {avgLoss : 4f}")
        
    # 모델 저장 디렉터리(프로젝트 루트/models) 생성
    saveDir = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__),  # src/riceDetect
            '..',                        # src
            '..',                        # uwc
            'models'                     # uwc/models
        )
    )
    os.makedirs(saveDir, exist_ok=True)

    # 가중치 파일 저장
    savePath = os.path.join(saveDir, 'riceSeg.pt')
    torch.save(model.state_dict(), savePath)
    print(f"Model saved to {savePath}")

if __name__ == '__main__' :
    trainSeg()    