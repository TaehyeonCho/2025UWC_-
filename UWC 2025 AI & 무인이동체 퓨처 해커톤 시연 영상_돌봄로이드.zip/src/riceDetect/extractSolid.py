# src/riceDetect/extractSolid.py

import os
import shutil

def extractSolid(
    # 프로젝트 루트(C:\uwc)에서 실행한다고 가정
    srcRoot = 'data/tranProteus1/Training/SingleObjectContent',
    dstRoot = 'data/transSolid'
):
    """
    tranProteus1/Training/SingleObjectContent 아래 모든 씬 폴더에서
    Depth(.png) 이미지와 대응 Mask(.png) 만 골라
    dstRoot/images/, dstRoot/masks/ 에 복사합니다.
    """
    imgDst  = os.path.join(dstRoot, 'images')
    maskDst = os.path.join(dstRoot, 'masks')
    os.makedirs(imgDst,  exist_ok=True)
    os.makedirs(maskDst, exist_ok=True)

    count = 0
    # 씬 폴더마다
    for scene in os.listdir(srcRoot):
        scenePath = os.path.join(srcRoot, scene)
        if not os.path.isdir(scenePath):
            continue
        # 씬 폴더 안 파일들
        for fn in os.listdir(scenePath):
            # Depth 이미지 파일만 선택
            if not fn.endswith('_Depth.png'):
                continue
            # 원본 이미지 경로
            srcImg  = os.path.join(scenePath, fn)
            # 대응 마스크 파일명
            maskName = fn.replace('_Depth.png', '_Mask.png')
            srcMask = os.path.join(scenePath, maskName)

            # 둘 다 존재하면 복사
            if os.path.isfile(srcImg) and os.path.isfile(srcMask):
                shutil.copy(srcImg,  imgDst)
                shutil.copy(srcMask, maskDst)
                count += 1

    print(f'추출 완료: {count}개 샘플을 {dstRoot} 에 복사했습니다.')

if __name__ == '__main__':
    extractSolid()
    
    
def measure_rice(image):
    """
    이미지를 입력받아 쌀 잔량(kg 등)을 반환합니다.
    실제로는 모델을 불러와서 추론해야 합니다.
    """
    # 예시: 항상 1.5 반환 (여기에 모델 추론 코드 추가 가능)
    return 1.5
