from PIL import Image
from ultralytics import YOLO

_model = None
def get_model():
    global _model
    if _model is None:
        # 휴지 전용 모델이 있으면 사용, 없으면 기본 모델 사용
        try:
            _model = YOLO("runs/detect/toiletpaper_train/weights/best.pt")
            print("휴지 전용 모델 로드됨")
        except:
            _model = YOLO("yolov8n.pt")
            print("기본 YOLO 모델 사용 (휴지 감지 정확도 낮을 수 있음)")
    return _model

def count_toiletpaper(image):
    """
    이미지를 입력받아 휴지 개수를 반환합니다.
    """
    model = get_model()
    results = model(image)
    # 신뢰도가 높은 박스만 카운트 (0.5 이상)
    valid_boxes = [box for box in results[0].boxes if box.conf > 0.5]
    count = len(valid_boxes)
    print(f"[DEBUG] 휴지 감지 박스 수: {len(results[0].boxes)}, 신뢰도 높은 박스: {count}")
    return count