import os
import glob
import shutil
from ultralytics import YOLO  # YOLOv8 사용
import cv2  # 이미지 전처리용 OpenCV
import torch  # 모델 연산(텐서) 처리용 pyTorch

# 데이터셋 경로 정의
DATASET_DIR = r"C:\uwc\data\toiletPaper"  # 학습, 검증 이미지가 들어있는 최상위 폴더 경로

# train/val 분리 후 저장할 폴더
TRAIN_DIR = os.path.join(DATASET_DIR, "train")
VAL_DIR = os.path.join(DATASET_DIR, "val")

# YAML 파일 경로
YAML_PATH = os.path.join(DATASET_DIR, "toiletpaper.yaml")

# 출력 (결과 이미지) 저장 폴더 정의
OUTPUT_DIR = os.path.join(os.getcwd(), "outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)  # 출력 폴더가 없으면 자동 생성

# 모델 불러오기
model = YOLO("yolov8n.pt")
device = 'cuda' if torch.cuda.is_available() else "cpu"
model.to(device)

# ============================= 데이터셋 파일 경로 수집 함수 ============================

def load_dataset_paths(dataset_dir):
    """
    images 및 labels 폴더를 재귀 탐색하여 확장자에 맞는 파일 경로 리스트 반환
    """
    image_exts = {'.jpg', '.jpeg', '.png', '.bmp'}
    label_exts = {'.txt'}

    img_paths = []
    lbl_paths = []

    for root, dirs, files in os.walk(dataset_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            full_path = os.path.join(root, fname)
            if ext in image_exts:
                img_paths.append(full_path)
            elif ext in label_exts:
                lbl_paths.append(full_path)

    return img_paths, lbl_paths

# =============================== 전처리 및 학습 데이터 준비 ==============================

def prepare_dataset(images):
    """
    데이터셋 폴더를 YOLOv8 형식으로 정리하는 함수
    """
    # 1) 원본 레이블 → train/labels 로 한 번만 이동
    raw_lbls = glob.glob(os.path.join(DATASET_DIR, 'labels', '*.txt'))
    os.makedirs(os.path.join(TRAIN_DIR, 'labels'), exist_ok=True)
    for lbl in raw_lbls:
        dst = os.path.join(TRAIN_DIR, 'labels', os.path.basename(lbl))
        shutil.move(lbl, dst)

    # 2) train/val 이미지·레이블 폴더 생성
    os.makedirs(os.path.join(TRAIN_DIR, 'images'), exist_ok=True)
    os.makedirs(os.path.join(VAL_DIR, 'images'), exist_ok=True)
    os.makedirs(os.path.join(VAL_DIR, 'labels'), exist_ok=True)

    # 3) 라벨이 있는 이미지만 필터링
    valid_images = []
    for img_path in images:
        fname = os.path.basename(img_path)
        lbl_path = os.path.join(DATASET_DIR, 'labels', os.path.splitext(fname)[0] + '.txt')
        if os.path.exists(lbl_path):
            valid_images.append(img_path)
        else:
            print(f"Warning: 라벨 파일을 찾을 수 없습니다: {lbl_path}")

    print(f"총 이미지 수: {len(images)}")
    print(f"라벨이 있는 이미지 수: {len(valid_images)}")

    # 4) images 리스트를 80:20으로 split 하여 옮기고, val이 되면 레이블도 이동
    split_idx = int(len(valid_images) * 0.8)
    for idx, img_path in enumerate(valid_images):
        fname = os.path.basename(img_path)
        lbl_path = os.path.join(DATASET_DIR, 'labels', os.path.splitext(fname)[0] + '.txt')

        if idx < split_idx:
            # -- train --
            shutil.move(img_path, os.path.join(TRAIN_DIR, 'images', fname))
            shutil.move(lbl_path, os.path.join(TRAIN_DIR, 'labels', os.path.basename(lbl_path)))
        else:
            # -- val --
            shutil.move(img_path, os.path.join(VAL_DIR, 'images', fname))
            shutil.move(lbl_path, os.path.join(VAL_DIR, 'labels', os.path.basename(lbl_path)))

def make_yaml():
    """
    train/val 경로와 클래스 정보를 담은 YAML 파일을 자동 생성
    """
    content = f"""\
train: {TRAIN_DIR.replace('\\', '/')}  # train images directory
val:   {VAL_DIR.replace('\\', '/')}    # val images directory

nc: 1                                 # number of classes
names: ['toiletpaper']                # class names
"""
    with open(YAML_PATH, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"YAML 파일 생성: {YAML_PATH}")

def train_toiletpaper_model():
    """
    휴지 감지용 YOLOv8 모델을 학습시키는 함수 (GPU 최적화)
    """
    print("휴지 감지 모델 학습 시작... (GPU 사용)")
    
    # YAML 파일 경로 확인
    if not os.path.isfile(YAML_PATH):
        print(f"YAML 파일을 찾을 수 없습니다: {YAML_PATH}")
        print("data/toiletPaper/data.yaml 파일을 확인해주세요.")
        return
    
    # GPU 메모리 최적화를 위한 학습 설정
    model = YOLO("yolov8n.pt")
    model.train(
        data=YAML_PATH,
        epochs=50,  # 에포크 수 줄임
        batch=8,    # 배치 크기 줄임 (메모리 절약)
        imgsz=640,
        device=device,
        project="runs/detect",
        name="toiletpaper_train",  # 휴지 전용 모델 이름
        patience=10,  # 조기 종료 에포크 줄임
        save=True,
        save_period=10,  # 10 에포크마다 모델 저장
        workers=2,    # 워커 수 줄임
        cache=False,  # 캐시 비활성화 (메모리 절약)
        amp=True,     # 자동 혼합 정밀도 유지
        optimizer="SGD",  # SGD 옵티마이저 사용 (메모리 절약)
        lr0=0.01,    # 학습률 조정
        lrf=0.1,     # 최종 학습률
        momentum=0.937,
        weight_decay=0.0005,
        warmup_epochs=1,  # 워밍업 에포크 줄임
        warmup_momentum=0.8,
        warmup_bias_lr=0.1,
        box=7.5,
        cls=0.5,
        dfl=1.5,
        pose=12.0,
        kobj=2.0,
        label_smoothing=0.0,
        nbs=64,
        overlap_mask=True,
        mask_ratio=4,
        dropout=0.0,
        val=True,
        plots=True,
        save_json=False,
        save_hybrid=False,
        conf=0.001,
        iou=0.6,
        max_det=300,
        half=True,    # FP16 사용
        dnn=False,
    )
    
    print("휴지 감지 모델 학습 완료!")
    print(f"모델 저장 위치: runs/detect/toiletpaper_train/weights/best.pt")

if __name__ == "__main__":
    print("스크립트 로드 성공")

    # 전체 데이터 경로 로드
    images, labels = load_dataset_paths(DATASET_DIR)  # images와 labels를 로드
    print(f"이미지 파일 수 : {len(images)}")
    print(f"레이블 파일 수 : {len(labels)}")

    # 데이터 준비 (train/val 분리 및 이동)
    prepare_dataset(images)

    # 모델 학습
    train_toiletpaper_model()
    
_model = None
def get_model():
    global _model
    if _model is None:
        _model = YOLO("runs/detect/train6/weights/best.pt")
    return _model

def count_toiletpaper(image):
    """
    이미지를 입력받아 휴지 개수를 YOLO로 감지합니다.
    """
    model = get_model()
    results = model(image)
    return len(results[0].boxes)