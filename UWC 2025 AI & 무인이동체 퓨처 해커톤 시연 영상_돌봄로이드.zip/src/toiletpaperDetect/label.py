from ultralytics import YOLO
import os
import cv2

# 모델 로드
model = YOLO('yolov8_trained_model.pt')  # 학습된 모델을 로드합니다.

# 이미지 폴더 경로 설정
img_folder = 'C:/path/to/new/images'  # 새로 생성할 이미지 폴더 경로

# 이미지 폴더 내 모든 이미지 파일 리스트 가져오기
images = [f for f in os.listdir(img_folder) if f.endswith(('.jpg', '.jpeg', '.png'))]

# 각 이미지에 대해 객체 탐지 실행 및 레이블 파일 생성
for img_file in images:
    # 이미지 파일 경로 설정
    img_path = os.path.join(img_folder, img_file)

    # 이미지 읽기
    img = cv2.imread(img_path)

    # 객체 탐지 실행
    results = model(img)

    # 탐지된 객체의 결과에서 바운딩 박스와 클래스 추출
    labels = results.pandas().xywh[0]  # (x_center, y_center, width, height, class)

    # 레이블 파일 저장
    label_file = os.path.splitext(img_file)[0] + '.txt'
    label_path = os.path.join('C:/path/to/save/labels', label_file)

    with open(label_path, 'w') as f:
        for index, row in labels.iterrows():
            # YOLO 형식: class_id x_center y_center width height (normalized)
            class_id = int(row['class'])
            x_center = row['xcenter']
            y_center = row['ycenter']
            width = row['width']
            height = row['height']
            f.write(f"{class_id} {x_center} {y_center} {width} {height}\n")

    print(f"레이블 파일이 생성되었습니다: {label_file}")